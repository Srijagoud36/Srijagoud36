"""
Server-rendered (session-based) auth views, used for the browsable
Recruiter Dashboard. The REST API (JWT) views live in views.py and are
what a JS/mobile frontend would use instead.
"""
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.shortcuts import render, redirect
from django import forms

from .models import User, CandidateProfile


class RegisterForm(UserCreationForm):
    email = forms.EmailField(required=True)
    role = forms.ChoiceField(choices=User.Role.choices)
    phone = forms.CharField(required=False)

    class Meta:
        model = User
        fields = ['username', 'email', 'role', 'phone', 'password1', 'password2']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.role = self.cleaned_data['role']
        user.email = self.cleaned_data['email']
        user.phone = self.cleaned_data.get('phone', '')
        if commit:
            user.save()
            if user.role == User.Role.CANDIDATE:
                CandidateProfile.objects.get_or_create(user=user)
        return user


def register_page(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Account created successfully.')
            return redirect('recruiter_dashboard' if user.is_recruiter else 'job_list_page')
    else:
        form = RegisterForm()
    return render(request, 'accounts/register.html', {'form': form})


def login_page(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            next_url = request.GET.get('next')
            if next_url:
                return redirect(next_url)
            return redirect('recruiter_dashboard' if user.is_recruiter else 'job_list_page')
        messages.error(request, 'Invalid username or password.')
    return render(request, 'accounts/login.html')


def logout_view(request):
    logout(request)
    messages.info(request, 'You have been logged out.')
    return redirect('login_page')
