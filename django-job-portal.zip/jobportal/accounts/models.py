from django.contrib.auth.models import AbstractUser
from django.core.validators import FileExtensionValidator
from django.core.exceptions import ValidationError
from django.conf import settings
from django.db import models


def validate_resume_size(value):
    max_size_mb = getattr(settings, 'MAX_RESUME_SIZE_MB', 5)
    if value.size > max_size_mb * 1024 * 1024:
        raise ValidationError(f'Resume file must be under {max_size_mb}MB.')


class User(AbstractUser):
    class Role(models.TextChoices):
        CANDIDATE = 'candidate', 'Candidate'
        RECRUITER = 'recruiter', 'Recruiter'

    role = models.CharField(max_length=10, choices=Role.choices, default=Role.CANDIDATE)
    phone = models.CharField(max_length=20, blank=True)

    def __str__(self):
        return f'{self.username} ({self.role})'

    @property
    def is_candidate(self):
        return self.role == self.Role.CANDIDATE

    @property
    def is_recruiter(self):
        return self.role == self.Role.RECRUITER


class CandidateProfile(models.Model):
    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='profile'
    )
    resume = models.FileField(
        upload_to='resumes/%Y/%m/',
        blank=True,
        null=True,
        validators=[
            FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx']),
            validate_resume_size,
        ],
        help_text='Allowed formats: PDF, DOC, DOCX. Max size 5MB.',
    )
    skills = models.CharField(max_length=500, blank=True, help_text='Comma-separated skills')
    experience_years = models.PositiveIntegerField(default=0)
    bio = models.TextField(blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f'Profile: {self.user.username}'
