# Django Job Portal

A job portal with candidate/recruiter roles, resume uploads, a server-rendered
recruiter dashboard, and a full REST API (JWT-authenticated).

## Features

- Custom `User` model with `role` = `candidate` or `recruiter`
- JWT auth (register / login / refresh) via `djangorestframework-simplejwt`
- Candidate profile with resume upload (PDF/DOC/DOCX, 5MB max, validated)
- Job CRUD — public browsing, recruiter-only create/edit/delete, ownership enforced
- Applications — candidates apply once per job, recruiters update status
  (applied → shortlisted / rejected / hired)
- Server-rendered recruiter dashboard (stats + job list + applicant management)
- Server-rendered public job listing + detail + apply pages (session auth)
- Search, filtering, and pagination on the API
- django-filter, django-cors-headers, Pillow wired in

## Tech Stack

Django 5.x · Django REST Framework · SimpleJWT · django-cors-headers ·
django-filter · Pillow · SQLite (dev) / PostgreSQL (prod-ready)

## Project Structure

```
jobportal/
├── manage.py
├── requirements.txt
├── .env.example
├── jobportal/          # project settings, root urls
├── accounts/           # custom User, CandidateProfile, auth API, login/register pages
├── jobs/                # Job, Application, job API, recruiter dashboard, public pages
├── templates/           # base.html + accounts/ + jobs/ templates
└── media/                # uploaded resumes (gitignored in production)
```

## Setup

```bash
# 1. Clone / unzip the project, then from the project root:
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt

# 3. Configure environment
cp .env.example .env
# Edit .env and set a real SECRET_KEY (e.g. via `python -c "import secrets; print(secrets.token_urlsafe(50))"`)

# 4. Run migrations
python manage.py migrate

# 5. Create an admin user
python manage.py createsuperuser

# 6. Run the dev server
python manage.py runserver
```

Visit:
- `http://127.0.0.1:8000/` — public job listing
- `http://127.0.0.1:8000/accounts/register/` — create a candidate or recruiter account
- `http://127.0.0.1:8000/dashboard/` — recruiter dashboard (recruiter accounts only)
- `http://127.0.0.1:8000/admin/` — Django admin
- `http://127.0.0.1:8000/api/` — REST API root (via router)

## Switching to PostgreSQL for Production

In `.env`:
```
DB_ENGINE=django.db.backends.postgresql
DB_NAME=jobportal
DB_USER=jobportal_user
DB_PASSWORD=your-password
DB_HOST=localhost
DB_PORT=5432
```
Install the driver: `pip install psycopg2-binary`, then re-run `python manage.py migrate`.

## API Endpoints

All API responses are JSON. Protected endpoints require:
`Authorization: Bearer <access_token>`

| Endpoint | Method | Auth | Purpose |
|---|---|---|---|
| `/api/auth/register/` | POST | Public | Register as candidate or recruiter, returns JWT tokens |
| `/api/auth/login/` | POST | Public | Login, returns JWT tokens |
| `/api/auth/refresh/` | POST | Public | Exchange refresh token for a new access token |
| `/api/auth/me/` | GET | JWT | Get the current authenticated user |
| `/api/candidate/resume/` | GET | JWT (candidate) | View own profile + resume |
| `/api/candidate/resume/` | POST | JWT (candidate) | Upload/update resume + profile fields |
| `/api/jobs/` | GET | Public | List active jobs (search, filter, paginate) |
| `/api/jobs/` | POST | JWT (recruiter) | Create a job |
| `/api/jobs/{id}/` | GET | Public | Job detail |
| `/api/jobs/{id}/` | PUT/PATCH/DELETE | JWT (owning recruiter) | Update/close/delete a job |
| `/api/jobs/?mine=true` | GET | JWT (recruiter) | List own jobs (incl. inactive) |
| `/api/jobs/{id}/applicants/` | GET | JWT (owning recruiter) | List applicants for a job |
| `/api/applications/` | GET | JWT | Own applications (candidate) or applications to own jobs (recruiter) |
| `/api/applications/` | POST | JWT (candidate) | Apply to a job (multipart: `job`, `resume`, `cover_letter`) |
| `/api/applications/{id}/` | GET/DELETE | JWT (owner/recruiter) | View/withdraw an application |
| `/api/applications/{id}/update_status/` | PATCH | JWT (owning recruiter) | Update application status |

### Job list query params
`?search=keyword` · `?job_type=full_time` · `?location=` · `?company=` ·
`?title=` · `?salary_min=` · `?salary_max=` · `?ordering=-created_at` · `?mine=true`

### Example requests

```bash
# Register a recruiter
curl -X POST http://127.0.0.1:8000/api/auth/register/ \
  -H "Content-Type: application/json" \
  -d '{"username":"acme_hr","email":"hr@acme.com","password":"StrongPass123","password_confirm":"StrongPass123","role":"recruiter"}'

# Login
curl -X POST http://127.0.0.1:8000/api/auth/login/ \
  -H "Content-Type: application/json" \
  -d '{"username":"acme_hr","password":"StrongPass123"}'

# Create a job (use access token from login)
curl -X POST http://127.0.0.1:8000/api/jobs/ \
  -H "Authorization: Bearer <ACCESS_TOKEN>" \
  -H "Content-Type: application/json" \
  -d '{"title":"Backend Engineer","description":"...","company":"Acme","location":"Remote","job_type":"remote","salary_min":80000,"salary_max":120000}'

# Apply to a job (candidate, multipart)
curl -X POST http://127.0.0.1:8000/api/applications/ \
  -H "Authorization: Bearer <ACCESS_TOKEN>" \
  -F "job=1" \
  -F "resume=@/path/to/resume.pdf" \
  -F "cover_letter=I'd love to join Acme."
```

## Validation & Security Notes

- Resume uploads are restricted to `.pdf`, `.doc`, `.docx` and capped at 5MB
  (`accounts/models.py::validate_resume_size`, enforced on both `CandidateProfile.resume`
  and `Application.resume`).
- `Application` has a `unique_together = ('job', 'candidate')` constraint — one
  application per candidate per job, enforced at both the DB and serializer level.
- Role-based permissions are enforced at **both** the view/permission-class
  level (`jobs/permissions.py`) and the object level (`has_object_permission`),
  so a recruiter can never edit another recruiter's job, and candidates can't
  see other candidates' applications.
- Pagination is on by default (`PAGE_SIZE = 10` in `REST_FRAMEWORK` settings).

## Production Checklist (not done in this dev scaffold)

- [ ] Set `DEBUG=False` and a strong random `SECRET_KEY` in `.env`
- [ ] Set `ALLOWED_HOSTS` to your real domain(s)
- [ ] Replace `CORS_ALLOWED_ORIGINS` with your actual frontend origin(s) — never use `CORS_ALLOW_ALL_ORIGINS = True`
- [ ] Switch to PostgreSQL (see above) and run `pip install psycopg2-binary`
- [ ] Serve media files (resumes) via S3/cloud storage rather than local disk
- [ ] Put Django behind gunicorn/uwsgi + nginx, run `collectstatic`
- [ ] Add `django-axes` or similar for login rate-limiting
- [ ] Enable HTTPS-only cookies (`SESSION_COOKIE_SECURE`, `CSRF_COOKIE_SECURE`)
- [ ] Add automated tests (not included in this scaffold — see below)

## Suggested Next Steps

- Add `pytest-django` tests for models, serializers, and permission edge cases
- Add email notifications on application status change
- Add a `JobBookmark` model for candidates saving jobs
- Add OpenAPI schema via `drf-spectacular` for interactive API docs
