from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from rest_framework.routers import DefaultRouter

from jobs.views import JobViewSet, ApplicationViewSet
from accounts import page_views
from accounts.views import ResumeUploadView

router = DefaultRouter()
router.register('jobs', JobViewSet, basename='job')
router.register('applications', ApplicationViewSet, basename='application')

urlpatterns = [
    path('admin/', admin.site.urls),

    # REST API
    path('api/auth/', include('accounts.urls')),
    path('api/candidate/resume/', ResumeUploadView.as_view(), name='api_resume_upload'),
    path('api/', include(router.urls)),

    # Server-rendered pages (login/register + recruiter dashboard)
    path('accounts/register/', page_views.register_page, name='register_page'),
    path('accounts/login/', page_views.login_page, name='login_page'),
    path('accounts/logout/', page_views.logout_view, name='logout_view'),
    path('', include('jobs.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATICFILES_DIRS[0])
