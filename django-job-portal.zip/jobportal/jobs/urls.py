from django.urls import path
from . import dashboard_views as views

urlpatterns = [
    path('', views.job_list_page, name='job_list_page'),
    path('jobs/<int:job_id>/', views.job_detail_page, name='job_detail_page'),
    path('dashboard/', views.recruiter_dashboard, name='recruiter_dashboard'),
    path('dashboard/jobs/new/', views.job_create, name='job_create'),
    path('dashboard/jobs/<int:job_id>/edit/', views.job_edit, name='job_edit'),
    path('dashboard/jobs/<int:job_id>/applicants/', views.job_applicants, name='job_applicants'),
]
