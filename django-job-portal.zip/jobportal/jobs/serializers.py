from rest_framework import serializers
from .models import Job, Application


class JobSerializer(serializers.ModelSerializer):
    recruiter_name = serializers.CharField(source='recruiter.username', read_only=True)
    applicant_count = serializers.IntegerField(read_only=True)
    has_applied = serializers.SerializerMethodField()

    class Meta:
        model = Job
        fields = [
            'id', 'title', 'description', 'company', 'location', 'job_type',
            'salary_min', 'salary_max', 'is_active', 'created_at', 'updated_at',
            'recruiter', 'recruiter_name', 'applicant_count', 'has_applied',
        ]
        read_only_fields = ['recruiter', 'created_at', 'updated_at']

    def get_has_applied(self, obj):
        request = self.context.get('request')
        if not request or not request.user.is_authenticated:
            return False
        if request.user.role != 'candidate':
            return False
        return obj.applications.filter(candidate=request.user).exists()

    def validate(self, attrs):
        salary_min = attrs.get('salary_min', getattr(self.instance, 'salary_min', None))
        salary_max = attrs.get('salary_max', getattr(self.instance, 'salary_max', None))
        if salary_min and salary_max and salary_min > salary_max:
            raise serializers.ValidationError('salary_min cannot be greater than salary_max.')
        return attrs


class ApplicationSerializer(serializers.ModelSerializer):
    candidate_name = serializers.CharField(source='candidate.username', read_only=True)
    job_title = serializers.CharField(source='job.title', read_only=True)
    company = serializers.CharField(source='job.company', read_only=True)

    class Meta:
        model = Application
        fields = [
            'id', 'job', 'job_title', 'company', 'candidate', 'candidate_name',
            'resume', 'cover_letter', 'status', 'applied_at', 'updated_at',
        ]
        read_only_fields = ['candidate', 'status', 'applied_at', 'updated_at']

    def validate_job(self, job):
        if not job.is_active:
            raise serializers.ValidationError('This job is no longer accepting applications.')
        return job

    def validate(self, attrs):
        request = self.context.get('request')
        job = attrs.get('job')
        if request and job and self.instance is None:
            if Application.objects.filter(job=job, candidate=request.user).exists():
                raise serializers.ValidationError('You have already applied to this job.')
        return attrs


class ApplicationStatusUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Application
        fields = ['status']
