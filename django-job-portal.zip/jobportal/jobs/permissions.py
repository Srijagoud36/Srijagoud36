from rest_framework.permissions import BasePermission, SAFE_METHODS


class IsRecruiterOrReadOnly(BasePermission):
    """
    Anyone (including anonymous users) can read/list/browse jobs.
    Only authenticated recruiters can create jobs.
    Only the owning recruiter can update/delete their own job.
    """

    def has_permission(self, request, view):
        if request.method in SAFE_METHODS:
            return True
        return bool(request.user and request.user.is_authenticated and request.user.role == 'recruiter')

    def has_object_permission(self, request, view, obj):
        if request.method in SAFE_METHODS:
            return True
        return obj.recruiter_id == request.user.id


class IsCandidate(BasePermission):
    """Only authenticated candidates may create applications."""

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated and request.user.role == 'candidate')


class IsApplicationOwnerOrRecruiter(BasePermission):
    """
    Candidates can view/manage their own applications.
    Recruiters can view/manage applications to jobs they own.
    """

    def has_object_permission(self, request, view, obj):
        user = request.user
        if user.role == 'candidate':
            return obj.candidate_id == user.id
        if user.role == 'recruiter':
            return obj.job.recruiter_id == user.id
        return False
