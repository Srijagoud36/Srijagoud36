from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.core.paginator import Paginator
from django import forms

from .models import Job, Application


def recruiter_required(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect(f'/accounts/login/?next={request.path}')
        if request.user.role != 'recruiter':
            messages.error(request, 'This page is only available to recruiters.')
            return redirect('job_list_page')
        return view_func(request, *args, **kwargs)
    return wrapper


class JobForm(forms.ModelForm):
    class Meta:
        model = Job
        fields = ['title', 'description', 'company', 'location', 'job_type',
                  'salary_min', 'salary_max', 'is_active']
        widgets = {'description': forms.Textarea(attrs={'rows': 6})}


@recruiter_required
def recruiter_dashboard(request):
    jobs = Job.objects.filter(recruiter=request.user).order_by('-created_at')
    total_applicants = Application.objects.filter(job__recruiter=request.user).count()
    status_counts = {
        choice_value: Application.objects.filter(
            job__recruiter=request.user, status=choice_value
        ).count()
        for choice_value, _ in Application.Status.choices
    }
    context = {
        'jobs': jobs,
        'total_jobs': jobs.count(),
        'active_jobs': jobs.filter(is_active=True).count(),
        'total_applicants': total_applicants,
        'status_counts': status_counts,
    }
    return render(request, 'jobs/recruiter_dashboard.html', context)


@recruiter_required
def job_create(request):
    if request.method == 'POST':
        form = JobForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.recruiter = request.user
            job.save()
            messages.success(request, 'Job posted successfully.')
            return redirect('recruiter_dashboard')
    else:
        form = JobForm()
    return render(request, 'jobs/job_form.html', {'form': form, 'title': 'Post a New Job'})


@recruiter_required
def job_edit(request, job_id):
    job = get_object_or_404(Job, id=job_id, recruiter=request.user)
    if request.method == 'POST':
        form = JobForm(request.POST, instance=job)
        if form.is_valid():
            form.save()
            messages.success(request, 'Job updated successfully.')
            return redirect('recruiter_dashboard')
    else:
        form = JobForm(instance=job)
    return render(request, 'jobs/job_form.html', {'form': form, 'title': f'Edit: {job.title}'})


@recruiter_required
def job_applicants(request, job_id):
    job = get_object_or_404(Job, id=job_id, recruiter=request.user)
    applications = job.applications.select_related('candidate').order_by('-applied_at')

    if request.method == 'POST':
        app_id = request.POST.get('application_id')
        new_status = request.POST.get('status')
        application = get_object_or_404(Application, id=app_id, job=job)
        if new_status in dict(Application.Status.choices):
            application.status = new_status
            application.save()
            messages.success(request, f'Updated status for {application.candidate.username}.')
        return redirect('job_applicants', job_id=job.id)

    paginator = Paginator(applications, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'jobs/job_applicants.html', {
        'job': job,
        'page_obj': page_obj,
        'status_choices': Application.Status.choices,
    })


class ApplyForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ['resume', 'cover_letter']
        widgets = {'cover_letter': forms.Textarea(attrs={'rows': 5})}


def job_detail_page(request, job_id):
    job = get_object_or_404(Job, id=job_id)
    already_applied = False
    form = None

    if request.user.is_authenticated and request.user.role == 'candidate':
        already_applied = Application.objects.filter(job=job, candidate=request.user).exists()
        if request.method == 'POST' and not already_applied and job.is_active:
            form = ApplyForm(request.POST, request.FILES)
            if form.is_valid():
                application = form.save(commit=False)
                application.job = job
                application.candidate = request.user
                application.save()
                messages.success(request, 'Application submitted successfully.')
                return redirect('job_detail_page', job_id=job.id)
        else:
            form = ApplyForm()

    return render(request, 'jobs/job_detail.html', {
        'job': job,
        'form': form,
        'already_applied': already_applied,
    })


def job_list_page(request):
    """Public job browsing page (candidates and anonymous visitors)."""
    jobs = Job.objects.filter(is_active=True).select_related('recruiter').order_by('-created_at')

    q = request.GET.get('q')
    location = request.GET.get('location')
    job_type = request.GET.get('job_type')
    if q:
        jobs = jobs.filter(title__icontains=q)
    if location:
        jobs = jobs.filter(location__icontains=location)
    if job_type:
        jobs = jobs.filter(job_type=job_type)

    paginator = Paginator(jobs, 10)
    page_obj = paginator.get_page(request.GET.get('page'))
    return render(request, 'jobs/job_list.html', {
        'page_obj': page_obj,
        'job_types': Job.JobType.choices,
    })
