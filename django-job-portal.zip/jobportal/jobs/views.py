from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, filters, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Job, Application
from .serializers import JobSerializer, ApplicationSerializer, ApplicationStatusUpdateSerializer
from .permissions import IsRecruiterOrReadOnly, IsCandidate, IsApplicationOwnerOrRecruiter
from .filters import JobFilter


class JobViewSet(viewsets.ModelViewSet):
    """
    /api/jobs/                 GET (public list), POST (recruiter only)
    /api/jobs/{id}/            GET, PUT/PATCH/DELETE (owning recruiter only)
    /api/jobs/{id}/applicants/ GET (owning recruiter only)
    /api/jobs/?mine=true       GET recruiter's own jobs (incl. inactive)
    /api/jobs/?search=keyword           free-text search (title/company/description/location)
    /api/jobs/?job_type=&location=&company=&title=&salary_min=&salary_max=
    /api/jobs/?ordering=-created_at,-salary_min
    """
    serializer_class = JobSerializer
    permission_classes = [IsRecruiterOrReadOnly]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = JobFilter
    search_fields = ['title', 'company', 'description', 'location']
    ordering_fields = ['created_at', 'salary_min', 'salary_max']

    def get_queryset(self):
        qs = Job.objects.select_related('recruiter').prefetch_related('applications')
        user = self.request.user

        if user.is_authenticated and user.role == 'recruiter' and self.request.query_params.get('mine') == 'true':
            return qs.filter(recruiter=user)
        return qs.filter(is_active=True)

    def get_serializer_context(self):
        return {'request': self.request}

    def perform_create(self, serializer):
        serializer.save(recruiter=self.request.user)

    @action(detail=True, methods=['get'], permission_classes=[IsAuthenticated])
    def applicants(self, request, pk=None):
        job = self.get_object()
        if job.recruiter_id != request.user.id:
            return Response({'detail': 'Not authorized to view applicants for this job.'}, status=403)
        apps = job.applications.select_related('candidate').all()
        page = self.paginate_queryset(apps)
        serializer = ApplicationSerializer(page or apps, many=True, context={'request': request})
        if page is not None:
            return self.get_paginated_response(serializer.data)
        return Response(serializer.data)


class ApplicationViewSet(viewsets.ModelViewSet):
    """
    /api/applications/                    GET (own, or recruiter's job applicants), POST (candidate only)
    /api/applications/{id}/               GET/DELETE
    /api/applications/{id}/update_status/ PATCH (owning recruiter only)
    """
    serializer_class = ApplicationSerializer
    permission_classes = [IsAuthenticated, IsApplicationOwnerOrRecruiter]

    def get_permissions(self):
        if self.request.method == 'POST':
            return [IsAuthenticated(), IsCandidate()]
        return super().get_permissions()

    def get_queryset(self):
        user = self.request.user
        if user.role == 'recruiter':
            return Application.objects.filter(job__recruiter=user).select_related('job', 'candidate')
        return Application.objects.filter(candidate=user).select_related('job', 'candidate')

    def get_serializer_context(self):
        return {'request': self.request}

    def perform_create(self, serializer):
        serializer.save(candidate=self.request.user)

    @action(detail=True, methods=['patch'], permission_classes=[IsAuthenticated])
    def update_status(self, request, pk=None):
        application = self.get_object()
        if application.job.recruiter_id != request.user.id:
            return Response({'detail': 'Only the job\'s recruiter can update application status.'}, status=403)
        serializer = ApplicationStatusUpdateSerializer(application, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(ApplicationSerializer(application, context={'request': request}).data)
